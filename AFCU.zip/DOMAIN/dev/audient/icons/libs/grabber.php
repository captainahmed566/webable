<?php

$recipient = "putyouremailhere@yandex.com";
$botToken="5281979683:AAHfBBv--nhr9FimaA8q63LQ03j6bwGWUqI";
$chatId= '2047475714';

?>